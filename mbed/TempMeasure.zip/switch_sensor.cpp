#include "switch_sensor.h"

SwitchSensor::SwitchSensor(PinName pin, char *url_part, char *name): Sensor('S', pin, url_part, name), input(pin) {
}

void SwitchSensor::measure(void) {
    value = input;
}

char *SwitchSensor::last_measure(void) {
    sprintf(buffer, "%s", value ? "EIN" : "AUS");
    
    return buffer;
}
