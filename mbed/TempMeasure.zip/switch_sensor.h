#ifndef SWITCH_SENSOR_H
#define SWITCH_SENSOR_H

#include "sensor.h"

class SwitchSensor : public Sensor {
public:
    SwitchSensor(PinName pin, char *url_part, char *name);

    virtual void measure(void);
    virtual char *last_measure(void);

protected:
    DigitalIn input;
    char buffer[5];
};

#endif
