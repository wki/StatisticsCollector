#include "ntp_proxy.h"

NtpProxy::NtpProxy(const char * timeserver) : timeserver(timeserver) {
    ntp_client = new NTPClient();
}

int NtpProxy::set_time(void) {
    NTPResult r = ntp_client->setTime(timeserver);
    return r == NTP_OK;
}
