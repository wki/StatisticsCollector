#include "sensor.h"

Sensor::Sensor(char kind, PinName pin, char *url_part, char *name) : kind(kind), pin(pin), url_part(url_part), name(name) {
    cleanup_measure();
}

void Sensor::set_value(int v) {
    value = v;
}

int Sensor::get_value(void) {
    return value;
}

char Sensor:: get_kind(void) {
    return kind;
}

int Sensor::get_pin(void) {
    return pin;
}

char *Sensor::get_url_part(void) {
    return url_part;
}

char *Sensor::get_name(void) {
    return name;
}

void Sensor::prepare_measure(void) {}

void Sensor::measure(void) {}

void Sensor::cleanup_measure(void) {
    value = 0;
}

char *Sensor::last_measure(void) {
    return NULL;
}
