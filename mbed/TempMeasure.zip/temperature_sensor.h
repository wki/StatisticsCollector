#ifndef TEMPERATURE_SENSOR_H
#define TEMPERATURE_SENSOR_H

#include "sensor.h"
#include "one_wire.h"

class TemperatureSensor : public Sensor {
public:
    TemperatureSensor(PinName pin, char *url_part, char *name);

    virtual void prepare_measure(void);
    virtual void measure(void);
    virtual char *last_measure(void);

protected:
    OneWire one_wire;
    char buffer[10];
};

#endif
