#ifndef LOCALTIME_H
#define LOCALTIME_H

#include "mbed.h"

class LocalTime {
public:
    LocalTime();
    
    struct tm *tm();

private:
    time_t last_sunday(int year, int month);
};

#endif
