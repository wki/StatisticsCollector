#ifndef NTP_PROXY_H
#define NTP_PROXY_H

#include "mbed.h"
#include "NTPClient.h"

class NtpProxy {
    NTPClient *ntp_client;

public:
    NtpProxy(const char *timeserver);
    
    int set_time(void);

private:
    const char *timeserver;
};

#endif
