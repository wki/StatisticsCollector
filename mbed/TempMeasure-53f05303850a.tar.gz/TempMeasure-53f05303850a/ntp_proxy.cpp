#include "ntp_proxy.h"

NtpProxy::NtpProxy(void) {
    ntp_client = new NTPClient();
}

int NtpProxy::set_time(void) {
    NTPResult r = ntp_client->setTime("time.apple.com");
    return r == NTP_OK;
}
