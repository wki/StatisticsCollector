#ifndef NTP_PROXY_H
#define NTP_PROXY_H

#include "mbed.h"
#include "NTPClient.h"

class NtpProxy {
    NTPClient *ntp_client;

public:
    NtpProxy(void);
    
    int set_time(void);
};

#endif
