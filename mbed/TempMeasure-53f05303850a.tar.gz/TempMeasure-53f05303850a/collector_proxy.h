#ifndef COLLECTOR_PROXY_H
#define COLLECTOR_PROXY_H

#include "mbed.h"
#include "HTTPClient.h"

class CollectorProxy {
public:
    CollectorProxy(char *url);
    int send_measure(char *path_part, int value); // result 1:OK, 0:fail

private:
    char *base_url;
};

#endif
